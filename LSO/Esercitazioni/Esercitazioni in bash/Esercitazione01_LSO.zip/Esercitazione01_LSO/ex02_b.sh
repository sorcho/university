#!/bin/bash

# Si scriva uno script bash che, data una directory in input,
# crei una cartella per ogni gruppo associato ad almeno un file nella directory 
# e in ognuna di queste una sotto-cartella associata
# ad ogni utente propietario di almeno un file associato a tale gruppo.
# All'interno di queste ultime lo script spostera' tutti i file
# appartenenti al gruppo di propieta' dell'utente.
# Chiedere se si vuole spostare il file oppure eliminarlo.

# Versione b

if [ $# -ne 1 ]; then
  printf "Error. Required 1 argument. Must be a full path directory\n"
  exit 1
elif [ ! -d $1 -o ! -r $1 -o ! -x $1 ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $1

fl=$(ls)
for f in $fl; do
  printf "\nDo you want to [M]ove or [D]elete %s?: [M/d] " $f
  a="M"; read a

  if [[ $a =~ ^[Dd] ]]; then
    printf "Deleting %s\n" $f
    rm -r $f
  else
    printf "Moving %s\n" $f
    ls -ld $f | awk '{system("mkdir -p "$4"/"$3" ; mv "$9" "$4"/"$3"/"$9"")}'  
  fi
done
