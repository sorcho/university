#!/bin/bash

# Utilizzando opportuni comandi in concatenazione
# elencare i nomi dei files regolari appartenenti
# all’utente oppure al gruppo in input

printf "Enter an username: "
u=""; read u

printf "Enter a group: "
g=""; read g

printf "Enter a directory [full path]: [Leave empty for current directory] "
d=""; read d

if [ -z $d ]; then
  d=$(pwd)
elif [ ! -d $d -o ! -r $d -o ! -x $d ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $d

printf "\nRegular files belonging to user %s or group %s in %s:\n" $u $g $d

ls -l |
awk '/^-/ && ($3 == "'$u'" || $4 == "'$g'") {print $9}' |
sort
