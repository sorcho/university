#!/bin/bash

# Usando awk, data una lista di stringhe separate dal carattere ":",
# sostituire la prima e la seconda stringa con il carattere "-".
# Le due stringhe non possono essere vuote

awk 'BEGIN {FS = OFS = ":"} $1 != "" && $2 != "" {$1 = $2 = "-"; print $0}'
