#!/bin/bash

# Scrivere l'equivalente del comando
#   echo "first:second:third" | awk -F ':' '{print $2}'
# con sed.

# version 1
echo "first:second:third" | sed -E 's/^[^:]*:{1}//; s/:.*$//'

# version 2
echo "first:second:third" | sed -En 's/.*:{1}(.*):{1}.*/\1/p'
