#!/bin/bash

# Utilizzando opportuni comandi in concatenazione
# elencare i nomi dei files modificati tra un anno di inizio e fine 

printf "Enter a start year: [Leave empty for current year] "
s=""; read s

if [ -z $s ]; then
  s=$(date +%Y)
elif [[ ! $s =~ ^[0-9]+$ ]]; then
  printf "Error. Not a valid year\n"
  exit 1
fi

printf "Enter an end year: [Leave empty for current year] "
e=""; read e

if [ -z $e ]; then
  e=$(date +%Y)
elif [[ ! $e =~ ^[0-9]+$ ]]; then
  printf "Error. Not a valid year\n"
  exit 1
fi

printf "Enter a directory [full path]: [Leave empty for current directory] "
d=""; read d

if [ -z $d ]; then
  d=$(pwd)
elif [ ! -d $d -o ! -r $d -o ! -x $d ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $d

printf "\nFiles modified between %d and %d in %s:\n" $s $e $d

ls -l --time-style="+%Y" |
awk 'NR > 1 && $6 >= '$s' && $6 <= '$e' {print $7}'
