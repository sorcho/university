#!/bin/bash

# Scrivere uno script BASH "visita.sh" che visita tutti i file
# della directory corrente.
# Per ogni file determina il suo tipo.
# Se il file e' leggibile.
# Se il file e' un file txt, doc, sh o c, visita.sh chiede all'utonto
# se si vuole vedere il suo contenuto mostrando solo le ultime 3 righe,
# mentre se il file e' una directory, visita.sh chiede se si vuole
# visitare anche la sottodirecotry.
# Per ogni file incontrato, visita.sh chiede se lo si vuole rimuovere
# prima di passare a gestire il prossimo file nella directory corrente

function visit() {
  cd $1
  fl=$(ls)
  for f in $fl; do
    printf "\nProcessing file %s/%s\n" $1 $f
    if [ -r $f ]; then
      if [[ $f =~ ^.+\.(doc|c|sh|txt)$ ]]; then
        printf "Do you want to see last 3 lines of %s? [Y/n]: " $f
        read a
        if [[ ! $a =~ ^[Nn] ]]; then
          printf "Last 3 lines of %s:\n\n" $f
          tail -n 3 $f
          printf "\n"
        fi
      elif [ -d $f ]; then
        d=$f
        printf "Do you want to visit directory %s? [Y/n]: " $d
        read a
        if [[ ! $a =~ ^[Nn] ]]; then
          visit $(pwd)"/"$d
          cd $1 
          f=$d
          printf "\nContinue processing file %s/%s\n" $1 $f
        fi
      fi
      printf "Do you want to remove %s? [N/y]: " $f
      read a
      if [[ $a =~ ^[Yy] ]]; then
        printf "Removing %s" $f
        rm -r $f 
      fi
    fi
  done
}

visit $(pwd)
