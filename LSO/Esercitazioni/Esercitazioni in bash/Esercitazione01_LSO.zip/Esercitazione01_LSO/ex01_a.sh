#!/bin/bash

# Utilizzando opportuni comandi in concatenazione
# contare quanti files hanno una estensione in input
# in una directory in input

printf "Insert a file extension. eg. [mp3], [pdf], [txt]: "
e=""; read e

printf "Enter a directory [full path]: [Leave empty for current directory] "
d=""; read d

if [ -z $d ]; then
  d=$(pwd)
elif [ ! -d $d -o ! -r $d -o ! -x $d ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $d

printf "\n# of files with %s extension in %s:\n" $e $d

e="\."$e"$"

ls |
grep -Ec $e
