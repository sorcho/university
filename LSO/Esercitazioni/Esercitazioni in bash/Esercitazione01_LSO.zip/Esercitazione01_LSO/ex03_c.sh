#!/bin/bash

# Dato un file in "stringhe.txt", estrarre tutte le righe contenenti
# la stringa "LSO" e "lso" e la riga subito dopo.
# Stamparle a video.

# p flag to print next line
awk '{
  if (index($0,"LSO") > 0 || index($0, "lso")) {print $0; p = 1}
  else {
    if (p) {print $0}
    p = 0
  }
}' stringhe.txt
