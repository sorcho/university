#!/bin/bash

# Si scriva uno script bash che, data una directory in input,
# crei una cartella per ogni gruppo associato ad almeno un file nella directory 
# e in ognuna di queste una sotto-cartella associata
# ad ogni utente propietario di almeno un file associato a tale gruppo.
# All'interno di queste ultime lo script spostera' tutti i file
# appartenenti al gruppo di propieta' dell'utente.

# Versione a

if [ $# -ne 1 ]; then
  printf "Error. Required 1 argument. Must be a full path directory\n"
  exit 1
elif [ ! -d $1 -o ! -r $1 -o ! -x $1 ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $1

ls -l |
awk 'NR > 1 {system("mkdir -p "$4"/"$3" ; mv "$9" "$4"/"$3"/"$9"")}'
