#!/bin/bash

# Dato un file fiori.txt contenente gli ordini di acquisto per fiori nella forma:
#   nome_persone nome_fiore quantita costo
# Stampare su un'unica riga per ogni utente i nomi dei fiori acquistati.

#version 1
sort fiori.txt |
awk '
  BEGIN {ORS = " "}
  {if (n != $1) {print "\n" $1 ": "; n = $1}}
  {print $2 " ["$3 " x " $4"$] "}
  END {ORS = "\n"; print ""}'


#version 2
awk '{a[$1] = a[$1] " " $2} END {for (i in a) print i, a[i]}' fiori.txt
