#!/bin/bash

# Utilizzando opportuni comandi in concatenazione
# stampare la dimensione totale occupata dai files regolari
# appartenenti al gruppo in input nella directory in input

printf "Enter a group: "
g=""; read g

printf "Enter a directory [full path]: [Leave empty for current directory] "
d=""; read d

if [ -z $d ]; then
  d=$(pwd)
fi

if [ ! -d $d -o ! -r $d -o ! -x $d ]; then
  printf "Error. Not a valid directory or not enough permission\n"
  exit 1
fi

cd $d

printf "\nTotal size [Byte] of regular files belonging to group %s in %s:\n" $g $d

ls -l |
awk 'BEGIN {s = 0} /^-/ && $4 == "'$g'" {s += $5} END {print s " B"}'

